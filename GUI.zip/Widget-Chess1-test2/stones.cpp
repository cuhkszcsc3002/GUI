#include <vector>
#include "stones.h"
#include <string>

