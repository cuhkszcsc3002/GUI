#ifndef STONES_H
#define STONES_H

#include <vector>
#include <string>
using namespace std;

class stones{

public:

static vector<string> Stone;

};
#endif // STONES_H
